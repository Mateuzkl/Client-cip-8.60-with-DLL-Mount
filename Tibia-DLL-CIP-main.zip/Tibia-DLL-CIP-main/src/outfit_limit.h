#ifndef TIBIA_OUTFIT_LIMIT_H
#define TIBIA_OUTFIT_LIMIT_H

#include <windows.h>

namespace OutfitLimit
{
	bool Install(DWORD clientBase, unsigned int limit);
}

#endif
