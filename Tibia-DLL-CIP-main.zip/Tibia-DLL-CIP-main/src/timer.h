#ifndef TIBIA_TIMER_H
#define TIBIA_TIMER_H

#include "main.h"

DWORD getTimerTick();

#endif
